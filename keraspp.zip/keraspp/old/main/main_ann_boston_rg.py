from kpp import ann_boston_rg


ann_boston_rg.main()
